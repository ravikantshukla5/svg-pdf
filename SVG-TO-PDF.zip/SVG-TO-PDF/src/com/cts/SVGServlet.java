package com.cts;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.batik.transcoder.Transcoder;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.fop.svg.PDFTranscoder;

/**
 * Servlet implementation class SVGServlet
 */
@WebServlet("/SVGServlet")
@MultipartConfig
public class SVGServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SVGServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream is = null;
		OutputStream out = response.getOutputStream();
		try{
			is = this.getClass().getClassLoader().getResourceAsStream("svg/chessboard.svg");
			TranscoderInput input_svg_image = new TranscoderInput(is);    
	         
	         TranscoderOutput output_pdf_document = new TranscoderOutput(out);         
	         
	         Transcoder transcoder = new PDFTranscoder();       
	        
	         response.setContentType("application/pdf");
	         
	         transcoder.transcode(input_svg_image, output_pdf_document);
		}catch(Exception e){
			e.printStackTrace();
		}
		finally {
            out.close();
    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			OutputStream out = response.getOutputStream();
			try{
				//is = this.getClass().getClassLoader().getResourceAsStream("svg/chessboard.svg");
				Part filePart = request.getPart("file"); // Retrieves <input type="file" name="file">
			    String fileName = filePart.getName();
				InputStream fileContent = filePart.getInputStream();
				TranscoderInput input_svg_image = new TranscoderInput(fileContent);    
		         
		         TranscoderOutput output_pdf_document = new TranscoderOutput(out);         
		         
		         Transcoder transcoder = new PDFTranscoder();       
		        
		         response.setContentType("application/pdf");
		         response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		         
		         transcoder.transcode(input_svg_image, output_pdf_document);
			}catch(Exception e){
				e.printStackTrace();
			}
			finally {
	            out.close();
	    }
		    
		}

}
